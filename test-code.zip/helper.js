const https = require('https');
module.exports = {
    makeAPICall : (defaultOptions, path, payload) => new Promise((resolve, reject) => {
        //stg
        const host = "ivr-qa.ual.com";
        //Prod
        //const host = "pualdpauth1.ual.com";
        const port = 443;
        
      const options = { ...defaultOptions, host, port, path, method: 'POST', agent: new https.Agent({
          rejectUnauthorized: false,
        }),
      };
        
      const req = https.request(options, res => {
            let buffer = "";
            res.on('data', chunk => buffer += chunk);
            res.on('end', function () {
                console.log('api response', buffer);
                resolve(JSON.parse(buffer));
            });
        });
        req.on('error', e => reject(e.message));
        //req.write(JSON.stringify(payload));
        req.write(payload);
        req.end();
    }),
    //read phone number from ANI
    extractPhoneNumber: function(ani) {
        var phoneNumber = "";
        if (ani.length == 10) {
            phoneNumber = ani.slice(3);
        }
        else if (ani.length == 12 && ani.startsWith("+1", 0)) {
            phoneNumber =  ani.slice(5);
        }
        else if (ani.length == 11 && ani.startsWith("1", 0)) {
            phoneNumber = ani.slice(4);
        }
        else {
            phoneNumber = " ";
        }   
        return phoneNumber;
    },
    
    //read phone number from ANI
    extractAreaCode: function(ani) {
        var areaCode = "";
        if (ani.length == 10) {
            areaCode = ani.substr(0, 3);
            }
        else if (ani.length == 12 && ani.startsWith("+1", 0)) {
            areaCode = ani.substr(2, 3);
            }
        else if (ani.length == 11 && ani.startsWith("1", 0)) {
            areaCode = ani.substr(1, 3);
            }
        else {
            areaCode = " ";
        }
        return areaCode;
    },
};