
const helper = require('./helper.js');

exports.handler = async (event) => {
    console.log(event); 
    const app_profile_id = "247_CUSTOMERIVR";
    const default_format = "json";
    
    const tokenOptions = {
        headers: {
         'Content-Type': 'application/x-www-form-urlencoded',
        }
    };
    
    console.log('event', JSON.stringify(event));
    
    // var ani = event.ANI;
    var ani = event.queryStringParameters.ANI;
    //var body = JSON.parse(event.body);
    //var ani = body.ANI;
    console.log('ani from connect', ani);
    
    //stg
    var token_Info = await helper.makeAPICall(tokenOptions, "/civr/token", 'client_id=LivePerson_Partner_9FEA8251-71D1-4B05-A9D6-8109F61BF8C7&client_secret=dvqDXzN8t97WJCHXW8QxKwQY&grant_type=client_credentials&scope=customerivr');
    //prod
    // API-Call Bearer Token
    //var token_Info = await helper.makeAPICall(tokenOptions, "/civr/token", 'client_id=LivePerson_Partner_9FEA8251-71D1-4B05-A9D6-8109F61BF8C7&client_secret=8jGGz4mryTHZP5P8ztvXvvVY&grant_type=client_credentials&scope=customerivr');
    var token = "Bearer "+ token_Info.access_token;
    
    console.log('access token', token);
     
    const sessionTokenOptions = {
        headers: {
         'Content-Type': 'application/json',
         'Authorization': token
        }
    };
    
    const sessionReqData = JSON.stringify({
      "ANI": ani,
      "AppProfileID": app_profile_id,
      "Version": "1.0",
      "SessionToken": "",
      "TokenStatus": "",
      "Format": default_format
    });
    
    // API-Call Session Token
    var session_token_response = await helper.makeAPICall(sessionTokenOptions, "/civr/tokenmanager/token", sessionReqData);
    console.log('session token', session_token_response.sessionToken);
  
    if (session_token_response.resultCode == 'E0000')
    {
        /*return {
        "statusCode": 200,
        "body": JSON.stringify(session_token_response)
        }*/
    return { 
                ani : session_token_response.ani || null,
                sessionToken : session_token_response.sessionToken || null,
                token: token|| null,
                tokenStatus : session_token_response.tokenStatus || null,
                expirationTimeInSeconds : session_token_response.expirationTimeInSeconds || null,
                responseTime : session_token_response.responseTime|| null,
                resultCode : session_token_response.resultCode || null,
                resultMessage : session_token_response.resultMessage || null,
            };
    }
    else 
    {
        return { 
                ani : null,
                sessionToken : null,
                token:  null,
                tokenStatus : null,
                expirationTimeInSeconds : null,
                responseTime : null,
                resultCode : null,
                resultMessage : null,
            };
    }
};
